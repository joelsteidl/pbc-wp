var gulp = require( 'gulp' ),
    notify = require( 'gulp-notify' ),
    del = require( 'del' ),
    zip = require( 'gulp-zip' );

var zipPath = [ './', './**', '!./node_modules', '!./node_modules/**', '!./includes/builder', '!./includes/builder/**', '!./build', '!./build/**', '!./gulpfile.js', '!./package.json', '!./package-lock.json', '!./webpack.config.js' ];

gulp.task( 'clean:zip', function() {
    return del( [ './build/**' ] );
} );

gulp.task('zip', [ 'clean:zip' ], function() {
    gulp.src( zipPath, { base : './' } )
        .pipe( zip( 'typehub.zip' ) )
        .pipe( gulp.dest( './build/' ) )
        .pipe( notify({
            message : 'Zip process complete',
            onLast : true
        }) );
});

gulp.task( 'default', [ 'zip' ] );